let value = 0;
let x = 25;
let y = 50;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  clear();
  rect(x, x, y, y);
  fill(value);
}

function mouseClicked() {
  for (let i = 0; i < 5; i++) {
    //Toggle fill value
    if (value === 0) {
      value = 255;
    } else {
      value = 0;
    }

    //Make canvas bigger
    x++;
    y++;
    //Clear and redraw canvas
    draw();
    console.log("responding to mouse click. Response number: " + (i + 1));
  }
}

function keyPressed() {
  let i = 0;
  while (i < 3) {
    //Toggle fill value
    if (value === 0) {
      value = 255;
    } else {
      value = 0;
    }

    //Make canvas smaller
    x--;
    y--;
    //Clear and redraw canvas
    draw();
    i++;
    console.log("responding to keypress. Response number " + i);
  }
}
