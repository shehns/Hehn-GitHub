function setup() {
  
  createCanvas(600, 600);
  background(200);
}

function draw() {
  colorMode(RGB,225,225,225,1);
  //
  fill(102,51,0);
  stroke(153,102,0,0.3);
  strokeWeight(5);
  triangle(325,375,360,320,394,375);
  //
  fill(200,50,0);
  stroke(130,30,0,0.5);
  strokeWeight(5);
  beginShape();
  vertex(335, 425);
  vertex(385, 425);
  vertex(385, 380);
  vertex(335, 380);
  endShape(CLOSE);
  //
  fill(255,16,200);
  stroke (51,51,51,0.3);
  ellipse(300,200,45,60);
  //
  fill(255,80,0,0.5);
  ellipse(400,100,45,60);
  //
  fill(100,200,255);
  ellipse(450,150,45,60);
  //
  fill(260,0,69);
  ellipse(250,189,45,60);
  //
  fill(0,159,100);
  ellipse(335,190,45,60);
  //
  fill(100,250,0,0.5);
  ellipse(350,130,45,60); 
  //
  fill(255,0,255);
  ellipse(260,130,45,60);
  //
  fill(255,200,0);
  ellipse(400,140,45,60);
  //
  fill(200,0,50,0.5);
  ellipse(390,200,45,60);
  //
  fill(250,80,50);
  ellipse(295,100,45,60); 
  //
  fill(200,150,0,0.5);
  ellipse(348,75,45,60);
  //
  fill(0,100,200,0.5);
  ellipse(300,166,45,60);
  //
  fill(100,100,200,0.5);
  ellipse(445,200,45,60);
  //
  line(360,320,335,220);
  line(360,320,450,230);
  line(360,320,390,230);
  line(360,320,250,220);
  line(360,320,300,230);  
  //
  fill(50,150,0);
  stroke(0,204,0);
  beginShape();
  curveVertex(600, 600);
  curveVertex(600, 600);
  curveVertex(400, 600);
  curveVertex(200, 400);
  curveVertex(0, 600);
  curveVertex(0, 600);
  endShape();

}